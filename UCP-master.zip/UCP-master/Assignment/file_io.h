#ifndef FILE_IO_H

    #define FILE_IO_H

    /* Function forward declarations */
    char* readSettingsFile( char*, int*, int*, int* );
    char* writeLogsFile( char*, LinkedList*, int, int, int );

#endif
