#ifndef TICTACTOE_H

    #define TICTACTOE_H

    /* Function Forward Declarations */
    void viewSettings( int, int, int );
    void viewLogs( LinkedList*, int, int, int );
    void saveLogs( LinkedList*, int, int, int );
    void editSettings( int*, int*, int* );

#endif
