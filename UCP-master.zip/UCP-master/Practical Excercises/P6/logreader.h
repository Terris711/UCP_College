#ifndef LOG_READER
#define LOG_READER

#endif
