#ifndef ARRAYS_H
    #define ARRAYS_H

    int sum( int*, int );

    int max( int*, int );

    void reverse( int*, int );

    void stringToInt( char**, int*, int );

    void printArray( int*, int );
#endif
