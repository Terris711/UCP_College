#ifndef USER_INPUT_H
    #define USER_INPUT_H

    void readInts( int*, int*, int*, char* );
#endif
