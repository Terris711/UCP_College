#ifndef UTILS_H
    #define UTILS_H

    int argToMenu( char* );

    void strToUpper( char* );
#endif
