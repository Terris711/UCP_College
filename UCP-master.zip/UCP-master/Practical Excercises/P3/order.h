static void testAscending( int*, int*, int* );

static void testDescending( int*, int*, int* );

static void ascending2( int*, int* );

static void ascending3( int*, int*, int* );

static void descending2( int*, int* );

static void descending3( int*, int*, int* );
