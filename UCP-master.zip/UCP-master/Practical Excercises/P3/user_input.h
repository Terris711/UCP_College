void readInts( int*, int*, int*, char* );
