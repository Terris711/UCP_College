#ifndef READER
#define READER

typedef struct {
    int day;
    int month;
    int year;
    char* text;
} Entry;

#endif
